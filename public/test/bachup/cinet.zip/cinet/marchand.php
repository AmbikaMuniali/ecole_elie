<?php
$marchand = array(
    "apikey" => "130463917365f879e9284415.37748505", // Enrer votre apikey
    "site_id" => "5883560", //Entrer votre site_ID
    "secret_key" => "aweerreretete45434123124!" //Entrer votre clé secret
);